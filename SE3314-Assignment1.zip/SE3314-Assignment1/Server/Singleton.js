// necessary declarations
var ts = 0;
var sn = 0;
module.exports = {
    init: function() {
       // init function needs to be implemented here //
       ts = Math.round(Math.random() * (999 - 1) + 1); // initializes a timestamp number from 1 to 999
       sn = Math.round(Math.random() * (999 - 1) + 1); // initializes a timestamp number from 1 to 9999
       setInterval(function(){ts++;},10); // increments timestamp number every 10 ms
    },
    //--------------------------
    //getSequenceNumber: return the current sequence number + 1
    //--------------------------
    getSequenceNumber: function() {
      // Enter your code here //
        sn += 1;
        return (sn + "");
    },

    //--------------------------
    //getTimestamp: return the current timer value
    //--------------------------
    getTimestamp: function() {
        return (ts + "");
    }


};