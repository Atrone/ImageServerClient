// necessary declarations
var ITPVersion = 3314;
var responseType = "1"; // responseType is always one because an error will be thrown if the image is not found
var sequenceNumber;
var timestamp;
var image;
var imageName;
var packetResponse;
var fs = require('fs');

function decimalToHexString(number)// needed due to size limit of buffer
{
    if (number < 0)
    {
        number = 0xFFFFFFFF + number + 1;
    }
    return (number.toString(16).toUpperCase());
}
module.exports = {

    init: function(reqdata, sn, ts) { // get data for ITPVersion, image, sequenceNumber, and timestamp when client connects
        ITPVersion = parseInt(reqdata.toString().slice(0,3),16); // get correct form for ITPVersion
        imageName = ((reqdata.toString().slice(4)).split(".")[0]) + ".jpg"; // get correct form for imageName
        image = fs.readFileSync("images/"+(imageName),function(err,data){ // get the image in buffer form
            if (err) throw err;
            console.log(data);
        });
        sequenceNumber = parseInt(sn); // get sequence number
        timestamp = parseInt(ts); // get timestamp
        console.log(image);
        console.log("HERE");
        },
    //--------------------------
    //getlength: return the total length of the ITP packet
    //--------------------------
    getLength: function() {
        // enter your code here
        return "length of ITP packet";
    },

    //--------------------------
    //getpacket: returns the entire packet
    //--------------------------
    getPacket: function() {
        // create new buffer for the ITP request packet header
        packetResponse = new Buffer.alloc(16);
        // write necessary data to buffer
        ITPVersion = decimalToHexString(ITPVersion);
        sequenceNumber = decimalToHexString(sequenceNumber);
        timestamp = decimalToHexString(timestamp);
        packetResponse.write(ITPVersion,0,3);
        packetResponse.write(responseType,3,1);
        packetResponse.write(sequenceNumber,4,3);
        packetResponse.write(timestamp,7,3);
        packetResponse.write(image.toString().length.toString(),10,6);
        return packetResponse;
    },
    getImage:function() // gets image
    {
        return image;
    }
};