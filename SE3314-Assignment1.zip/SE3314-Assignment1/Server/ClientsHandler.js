// necessary declarations
var ITPpacket = require('./ITPpacketResponse'),
    singleton = require('./Singleton');
var millisecondsToWait = 100;
module.exports = {

    handleClientJoining: function (sock) {
        // on writing from client to server
        sock.on('data', function(reqdata) {
            // init response packet with request packet data, sequence number, and timestamp
            ITPpacket.init(reqdata, singleton.getSequenceNumber(), singleton.getTimestamp());
            sock.write(ITPpacket.getPacket()); // write packet to client
            setTimeout(function() {
                sock.write(ITPpacket.getImage()); // write image to client
            }, millisecondsToWait);
            console.log("here");
        });
    }
};


