// necessary declarations
var ITPVersion = 3314;
var requestType = "1";
var imgName = "swan.jpg";
var packetRequest;
function decimalToHexString(number) // needed due to size limit of buffer
{
    if (number < 0)
    {
        number = 0xFFFFFFFF + number + 1;
    }
    return (number.toString(16).toUpperCase());
}
module.exports = {
    init: function(imgName1) {
        // get clients image name
        imgName = imgName1;
    },
    //--------------------------
    //getpacket: returns the entire packet
    //--------------------------
    getpacket: function() {
        // create new buffer for the ITP request packet
        packetRequest = new Buffer.alloc(12);
        // write to buffers
        ITPVersion = decimalToHexString(ITPVersion);
        packetRequest.write((ITPVersion),0,3);
        packetRequest.write(requestType,3,1);
        packetRequest.write(imgName,4,8);
        return packetRequest;
    },
    
};

