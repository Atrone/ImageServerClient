// necessary declarations
var net = require('net');
var fs = require('fs');
var ITPpacket = require('./ITPpacketRequest');

var opn = require('opn');

// init host port and imgName vars
var HOST = '127.0.0.1';
var PORT = 3000;
var imgName = 'swan.jpg';

// grab command line arguments
process.argv.forEach(function (val, index, array) {
    console.log(index + ': ' + val);
    if(index == 3)
    {
        HOST = val.split(":")[0];
        PORT = val.split(":")[1];
    }
    if(index == 5)
    {
        imgName = val.split("j")[0];
    }
  });
// Enter your code for the client functionality here
// Consider the code given in unit 7 slide 40 as a base and build upon it

// code for client functionality
var client = new net.Socket();
client.connect(PORT, HOST, function() {
console.log('Connected to ImageDB server on: ' + HOST + ':' + PORT);
ITPpacket.init(imgName);
client.write(ITPpacket.getpacket());
});
client.on('data', function(resdata) { // on writing from server to client
  console.log("clientData");
if(parseInt(resdata.toString().slice(0,3),16).toString() == "3314")
{
  console.log('Server Sent: \n\n' + 
  "--ITPVersion = " + parseInt(resdata.toString().slice(0,3),16).toString() + "\n"
  + "--Response Type = " + parseInt(resdata.toString().slice(3,4)).toString() + "\n"
  + "--Sequence Number = " + parseInt(resdata.toString().slice(4,7),16).toString() + "\n"
  + "--Timestamp = " + parseInt(resdata.toString().slice(7,10),16).toString() + "\n"
  + "--Image size = " + parseInt(resdata.toString().slice(10,16)).toString() + "\n"
  );
}
else{
  console.log((imgName + 'jpg'));
  console.log((resdata));
  fs.writeFileSync((imgName + 'jpg'), (resdata),'binary', (err) => {
      if (err) throw err;
      console.log('The file has been saved!');
    });
    opn((imgName + 'jpg')).then(() => { // open image viewer
      // image viewer closed
  });
  client.destroy();  
}
});
client.on('close', function() {
console.log('Connection closed');
});